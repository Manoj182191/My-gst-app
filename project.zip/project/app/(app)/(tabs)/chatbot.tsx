import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useTheme } from '../../../context/ThemeContext';
import { useLanguage } from '../../../context/LanguageContext';
import { Send, Mic, Bot } from 'lucide-react-native';
import Text from '../../../components/ui/Text';
import Card from '../../../components/ui/Card';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function ChatbotScreen() {
  const { theme } = useTheme();
  const { t } = useLanguage();
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I am your AI assistant. How can I help you with your GST and accounting queries today?',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  
  const [inputText, setInputText] = useState('');
  
  const handleSend = () => {
    if (!inputText.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInputText('');
    
    // Simulate bot response
    setTimeout(() => {
      const botResponses = [
        "I can help you calculate GST for your invoices. Would you like me to explain the different GST rates?",
        "For IGST calculations, you need to apply a single tax rate for inter-state transactions. The standard rates are 5%, 12%, 18%, and 28%.",
        "To generate an e-way bill, you'll need invoice details, transporter information, and item descriptions. Would you like me to guide you through the process?",
        "Your business's GST filing deadline is approaching. Make sure to submit your returns by the 20th of this month to avoid penalties.",
        "Based on your recent transactions, I notice your input tax credit is ₹15,400. Would you like me to help you claim this amount?",
      ];
      
      const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)];
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: randomResponse,
        sender: 'bot',
        timestamp: new Date(),
      };
      
      setMessages((prevMessages) => [...prevMessages, botMessage]);
    }, 1000);
  };
  
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
        <Text variant="h4" style={styles.title}>
          {t('chatbot')}
        </Text>
      </View>
      
      <Card style={styles.chatInfo}>
        <View style={styles.botIconContainer}>
          <Bot size={24} color={theme.colors.primary} />
        </View>
        <Text variant="body2" style={styles.chatInfoText}>
          Ask me anything about GST calculations, tax filing, or accounting assistance.
        </Text>
      </Card>
      
      <ScrollView
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        showsVerticalScrollIndicator={false}
      >
        {messages.map((message) => (
          <View
            key={message.id}
            style={[
              styles.messageBubble,
              message.sender === 'user'
                ? [styles.userBubble, { backgroundColor: theme.colors.primary }]
                : [styles.botBubble, { backgroundColor: theme.colors.cardBackgroundAlt }],
            ]}
          >
            <Text
              variant="body2"
              color={message.sender === 'user' ? theme.colors.white : theme.colors.text}
            >
              {message.text}
            </Text>
            <Text
              variant="caption"
              color={message.sender === 'user' ? 'rgba(255, 255, 255, 0.7)' : theme.colors.textSecondary}
              style={styles.timestamp}
            >
              {formatTime(message.timestamp)}
            </Text>
          </View>
        ))}
      </ScrollView>
      
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <View style={[styles.inputContainer, { backgroundColor: theme.colors.cardBackground }]}>
          <TextInput
            style={[
              styles.input,
              { color: theme.colors.text, backgroundColor: theme.colors.inputBackground },
            ]}
            placeholder="Type your message..."
            placeholderTextColor={theme.colors.textSecondary}
            value={inputText}
            onChangeText={setInputText}
            multiline
          />
          <View style={styles.inputActions}>
            <TouchableOpacity
              style={[styles.iconButton, { backgroundColor: theme.colors.cardBackgroundAlt }]}
            >
              <Mic size={20} color={theme.colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.sendButton,
                { backgroundColor: inputText.trim() ? theme.colors.primary : theme.colors.cardBackgroundAlt },
              ]}
              onPress={handleSend}
              disabled={!inputText.trim()}
            >
              <Send
                size={20}
                color={inputText.trim() ? theme.colors.white : theme.colors.textSecondary}
              />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
  },
  chatInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  botIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(79, 70, 229, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  chatInfoText: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  messagesContent: {
    paddingTop: 8,
    paddingBottom: 16,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 8,
  },
  userBubble: {
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  botBubble: {
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  timestamp: {
    alignSelf: 'flex-end',
    marginTop: 4,
    fontSize: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  input: {
    flex: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    maxHeight: 100,
  },
  inputActions: {
    flexDirection: 'row',
    marginLeft: 8,
    gap: 8,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});